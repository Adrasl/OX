-La generaci�n de la tabla de temporizaci�n en el documento 'Propuesta PFC-AJSL-2009-10-19' ha dado problemas con el formato .doc, por lo que se adjunta en formatos .odt (OppenOffice) y .pdf
-Se conservan las referencias concretas a los cursos en el informe de estado, se consideraban de relevancia para el estudio del estado del arte y la recopilaci�n de documentaci�n sobre las t�cnicas de creaci�n que se pretenden conseguir con la aplicaci�n inform�tica, igualmente se planea realizar documentaci�n sobre composici�n musical (se ha estimado s�lo una fracci�n de las horas aprovechables para el proyecto de las dedicadas como trabajo previo de documentaci�n).
-Se ha quitado a �scar D�niz como co-tutor del PFC porque ha dejado de estar disponible. El tutor principal sigue siendo Modesto.
-Se han asignado nombres a las actividades a�adidas en el sistema como 'trabajo previo' describiendo la actividad a la que pertenecen.
-RRHH y comunicaciones: se han hecho cambios en la periodicidad m�nima de contacto.


